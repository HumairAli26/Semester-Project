#pragma once
#include "user.h"
#include <string>
using namespace std;

class voter : virtual public user {
private:
    string voterID;
    bool hasvoted;
    string area;

public:
    // Constructors
    voter();
    voter(string n, int a, string c, string cn, string r, string p, string vid, string assigned_area);

    // Getters & Setters
    void sethasvoted(bool voted);
    bool gethasvoted() const;
    string getVoterID() const;
    string getArea() const;

    // Core Functions
    void setDetails();
    void update();
    void cast_vote(const string &voterID_loggedIn);
    void displayDetails();
    void saveToFile();
    void deleteVoter();
    void deleteAllVoters();
    bool matchArea(const string &voterArea);
    void showrole() override;
    void displayMenu(voter &v);
};
