#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include "candidate.h"
using namespace std;

class provincial {
private:
    string provincename;
    int provinceid;
    string* cities;
    int citycount;
    int cityCapacity;
    candidate** candidates;
    int candidatecount;
    int candidateCapacity;
    bool electionStarted;

    void resizeCities();
    void resizeCandidates();

public:
    provincial(string name = "", int id = 0);
    ~provincial();

    void addCity(const string& city);
    void loadCandidatesFromFile();
    void createElection();
    void showCandidates();
    string getWinningParty();

    int getCandidateCount() const;
    candidate* getCandidateAt(int index);
    string getProvinceName() const;
    bool hasStarted() const;
};
