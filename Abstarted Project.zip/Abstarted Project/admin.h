#ifndef ADMIN_H
#define ADMIN_H

#include "voter.h"
#include "candidate.h"
#include "result.h"
#include "graph.h"
#include <string>
using namespace std;

class admin : public voter, public Result {
    int electionCount;

    void approveRole(const string &targetRole, const string &outputFile);
    void handleUserApprovalMenu();
    void handleUserAddMenu();
    void handleUserUpdateMenu();
    void handleUserRemoveMenu();

public:
    admin(string name = "", int age = 0, string city = "", string cnic = "", string role = "Admin", string password = "");

    void adminMenu();
    void createElection();
    void showResults();
    void resetResults();
    void deleteAllVotersData();

    void addNewVoter();
    void updateVoter();
    void removeVoter();

    void addCandidate();
    void updateCandidate();
    void removeCandidate();

    void approveVoters();
    void approveCandidates();
    void approveAdmins();

    void showrole() override;
};

#endif
