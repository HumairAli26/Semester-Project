#pragma once
#include "candidate.h"
#include "graph.h"
#include <string>
using namespace std;

class Result : virtual public candidate, virtual public Graph {
private:
    string status;

public:
    Result();
    Result(const candidate& c, string winStatus);

    void setStatus(string s);
    string getStatus() const;

    void saveResultToFile() const;

    static void resetResults();
    static void showAreaResults(const string& areaName);
    void showLeadingParty();
};
