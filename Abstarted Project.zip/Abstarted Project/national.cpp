#include "national.h"

national_election::national_election() {
    provinceCount = 0;
    provinceCapacity = 3;
    provinces = new provincial*[provinceCapacity];
}

national_election::~national_election() {
    delete[] provinces;
}

void national_election::resizeProvinces() {
    provinceCapacity *= 2;
    provincial** newArray = new provincial*[provinceCapacity];
    for (int i = 0; i < provinceCount; i++) {
        newArray[i] = provinces[i];
    }
    delete[] provinces;
    provinces = newArray;
}

void national_election::addProvince(provincial* p) {
    if (provinceCount == provinceCapacity)
        resizeProvinces();
    provinces[provinceCount++] = p;
}

void national_election::createElection() {
    cout << Green << "National Election Started!\n" << Reset;
    for (int i = 0; i < provinceCount; i++) {
        provinces[i]->createElection();
    }
}

void national_election::showAllCandidates() {
    for (int i = 0; i < provinceCount; i++) {
        cout << Cyan << "Province: " << provinces[i]->getProvinceName() << Reset << endl;
        provinces[i]->showCandidates();
    }
}

string national_election::getNationalWinner() {
    string* parties = new string[provinceCount];
    int* wins = new int[provinceCount];
    int partyCount = 0;

    for (int i = 0; i < provinceCount; i++) {
        string winner = provinces[i]->getWinningParty();
        if (winner == "None") continue;

        bool found = false;
        for (int j = 0; j < partyCount; j++) {
            if (parties[j] == winner) {
                wins[j]++;
                found = true;
                break;
            }
        }

        if (!found) {
            parties[partyCount] = winner;
            wins[partyCount++] = 1;
        }
    }

    string nationalWinner = "No party";
    int max = 0;
    for (int i = 0; i < partyCount; i++) {
        if (wins[i] > max) {
            max = wins[i];
            nationalWinner = parties[i];
        }
    }

    delete[] parties;
    delete[] wins;
    return nationalWinner;
}
