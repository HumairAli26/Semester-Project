#include "admin.h"
#include <iostream>
#include <fstream>
#include <ctime>
using namespace std;

const string White = "\033[37m";
const string Red = "\033[31m";
const string Green = "\033[32m";
const string Blue = "\033[34m";
const string Yellow = "\033[33m";
const string Cyan = "\033[36m";
const string Magenta = "\033[35m";
const string Bold = "\033[1m";
const string Reset = "\033[0m";

admin::admin(string name, int age, string city, string cnic, string role, string password)
    : user(name, age, city, cnic, role, password), electionCount(0) {}

void admin::adminMenu() {
    int choice;
    do {
        cout << "=====================================================================" << endl;
        cout << White << "                              ADMIN MENU                             " << endl;
        cout << "=====================================================================" << endl;
        cout << "\t\t\t\t" << Blue << "1." << Reset << " Create Election" << endl;
        cout << "\t\t\t\t" << Blue << "2." << Reset << " Add Users" << endl;
        cout << "\t\t\t\t" << Blue << "3." << Reset << " Update Users" << endl;
        cout << "\t\t\t\t" << Blue << "4." << Reset << " Remove Users" << endl;
        cout << "\t\t\t\t" << Blue << "5." << Reset << " Show Results " << endl;
        cout << "\t\t\t\t" << Blue << "6." << Reset << " Reset Results " << endl;
        cout << "\t\t\t\t" << Blue << "7." << Reset << " Delete All Voters " << endl;
        cout << "\t\t\t\t" << Blue << "8." << Reset << " Approve Pending Users" << endl;
        cout << "\t\t\t\t" << Blue << "0." << Reset << " Logout" << endl;
        cout << "=====================================================================" << endl;

        cout << "\t\t\tEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: createElection(); break;
            case 2: handleUserAddMenu(); break;
            case 3: handleUserUpdateMenu(); break;
            case 4: handleUserRemoveMenu(); break;
            case 5: showResults(); break;
            case 6: resetResults(); break;
            case 7: deleteAllVotersData(); break;
            case 8: handleUserApprovalMenu(); break;
            case 0: cout << Green << "Logging out...\n" << Reset; return;
            default: cout << Red << "Invalid choice, try again.\n" << Reset;
        }
    } while (choice != 0);
}

void admin::handleUserAddMenu() {
    while (true) {
        cout << White << "                              ADD USERS                             " << endl;
        cout << Blue << "\t\t\t\t1." << Reset << " Voter\n";
        cout << Blue << "\t\t\t\t2." << Reset << " Candidate\n";
        cout << Blue << "\t\t\t\t0." << Reset << " Back\n";

        int n;
        cout << "\t\t\tEnter choice: ";
        cin >> n;
        if (n == 1) addNewVoter();
        else if (n == 2) addCandidate();
        else if (n == 0) break;
    }
}

void admin::handleUserUpdateMenu() {
    while (true) {
        cout << White << "                              UPDATE USERS                             " << endl;
        cout << Blue << "\t\t\t\t1." << Reset << " Voter\n";
        cout << Blue << "\t\t\t\t2." << Reset << " Candidate\n";
        cout << Blue << "\t\t\t\t0." << Reset << " Back\n";

        int n;
        cout << "\t\t\tEnter choice: ";
        cin >> n;
        if (n == 1) updateVoter();
        else if (n == 2) updateCandidate();
        else if (n == 0) break;
    }
}

void admin::handleUserRemoveMenu() {
    while (true) {
        cout << White << "                              REMOVE USERS                             " << endl;
        cout << Blue << "\t\t\t\t1." << Reset << " Voter\n";
        cout << Blue << "\t\t\t\t2." << Reset << " Candidate\n";
        cout << Blue << "\t\t\t\t0." << Reset << " Back\n";

        int n;
        cout << "\t\t\tEnter choice: ";
        cin >> n;
        if (n == 1) removeVoter();
        else if (n == 2) removeCandidate();
        else if (n == 0) break;
    }
}

void admin::handleUserApprovalMenu() {
    while (true) {
        cout << White << "                              PENDING USERS                             " << endl;
        cout << Blue << "\t\t\t\t1." << Reset << " Voters\n";
        cout << Blue << "\t\t\t\t2." << Reset << " Candidates\n";
        cout << Blue << "\t\t\t\t3." << Reset << " Admin\n";
        cout << Blue << "\t\t\t\t0." << Reset << " Back\n";

        int n;
        cout << "\t\t\tEnter choice: ";
        cin >> n;
        if (n == 1) approveVoters();
        else if (n == 2) approveCandidates();
        else if (n == 3) approveAdmins();
        else if (n == 0) break;
    }
}

void admin::createElection() {
    cout << Bold << "\t\t\t\t=== Create New Election ===" << Reset << endl;
    int electionType;
    string provinceName;
    ofstream file;

    cout << "\t\t\t\tWhich type of election do you want to start?\n";
    cout << Cyan << "\t\t\t\t1. National Election" << Reset << endl;
    cout << Cyan << "\t\t\t\t2. Provincial Election" << Reset << endl;
    cout << "\t\t\tEnter your choice: ";
    cin >> electionType;

    int year, month, day, hour, minute;
    cout << "Enter election end date and time (YYYY MM DD HH MM): ";
    cin >> year >> month >> day >> hour >> minute;

    tm end_tm = {};
    end_tm.tm_year = year - 1900;
    end_tm.tm_mon = month - 1;
    end_tm.tm_mday = day;
    end_tm.tm_hour = hour;
    end_tm.tm_min = minute;

    time_t endTime = mktime(&end_tm);
    if (endTime == -1) {
        cout << Red << "Invalid time entered." << Reset << endl;
        return;
    }

    char* endTimeStr = ctime(&endTime);

    switch (electionType) {
        case 1:
            file.open("national_election.txt", ios::app);
            if (!file.is_open()) {
                cout << Red << "Error: Could not open national_election.txt." << Reset << endl;
                return;
            }
            file << "----------------------" << endl;
            file << "ElectionType: National" << endl;
            file << "Election Number: " << ++electionCount << endl;
            file << "End Time: " << endTimeStr;
            file << "----------------------" << endl;
            cout << Green << "National Election started successfully." << Reset << endl;
            break;
        case 2:
            cin.ignore();
            cout << "Enter province name: ";
            getline(cin, provinceName);
            file.open("provincial_election.txt", ios::app);
            if (!file.is_open()) {
                cout << Red << "Error: Could not open provincial_election.txt." << Reset << endl;
                return;
            }
            file << "----------------------" << endl;
            file << "ElectionType: Provincial" << endl;
            file << "Province: " << provinceName << endl;
            file << "Election Number: " << ++electionCount << endl;
            file << "End Time: " << endTimeStr;
            file << "----------------------" << endl;
            cout << Green << provinceName << " Provincial Election started successfully." << Reset << endl;
            break;
        default:
            cout << Red << "Invalid election type selected." << Reset << endl;
            break;
    }
    file.close();
}

void admin::addCandidate() { candidate c; c.setDetails(); c.saveToFile(); cout << Green << "Candidate added successfully.\n" << Reset; }
void admin::updateCandidate() { candidate c; c.update(); }
void admin::removeCandidate() { candidate c; c.removeCandidate(); }
void admin::addNewVoter() { voter v; v.setDetails(); v.saveToFile(); cout << Green << "New voter added successfully.\n" << Reset; }
void admin::updateVoter() { voter v; v.update(); }
void admin::removeVoter() { voter v; v.deleteVoter(); }
void admin::deleteAllVotersData() { voter v; v.deleteAllVoters(); }

void admin::resetResults() { Result::resetResults(); cout << Green << "All election results have been reset.\n" << Reset; }

void admin::showResults() {
    string area;
    int choice;
    cout << "\nChoose result type:\n1. National Election\n2. Provincial Election\n3. Area-wise Result\nEnter: ";
    cin >> choice;
    cin.ignore();

    switch (choice) {
        case 1:
            Result::showLeadingParty();
            Graph::drawPartyGraph();
            break;
        case 2:
            cout << "Provincial results feature under development.\n";
            break;
        case 3:
            cout << "Enter area name: ";
            getline(cin, area);
            Result::showAreaResults(area);
            Graph::drawCandidateGraph(area);
            break;
        default:
            cout << Red << "Invalid input!\n" << Reset;
    }
}

void admin::approveRole(const string &targetRole, const string &outputFile) {
    ifstream inFile("Approval.txt");
    ofstream tempFile("temp.txt");
    ofstream outFile(outputFile, ios::app);

    if (!inFile || !tempFile || !outFile) {
        cout << "File open error.\n";
        return;
    }

    string line;
    string record[1000];
    int index = 0;

    while (getline(inFile, line)) {
        if (line == "----------") {
            if (index >= 5 && record[4] == targetRole) {
                cout << "\nPending " << targetRole << ":\n";
                for (int i = 0; i < index; i++) cout << record[i] << endl;
                cout << "\nApprove this " << targetRole << "? (y/n): ";
                char choice;
                cin >> choice;
                cin.ignore();

                if (choice == 'y' || choice == 'Y') {
                    for (int i = 0; i < index; i++) outFile << record[i] << endl;
                    outFile << "----------" << endl;
                    cout << targetRole << " approved.\n";
                } else {
                    for (int i = 0; i < index; i++) tempFile << record[i] << endl;
                    tempFile << "----------" << endl;
                    cout << targetRole << " skipped.\n";
                }
            } else {
                for (int i = 0; i < index; i++) tempFile << record[i] << endl;
                tempFile << "----------" << endl;
            }
            index = 0;
        } else {
            if (index < 1000) record[index++] = line;
        }
    }

    inFile.close();
    tempFile.close();
    outFile.close();

    remove("Approval.txt");
    rename("temp.txt", "Approval.txt");
}

void admin::approveVoters() { approveRole("Voter", "voter.txt"); }
void admin::approveCandidates() { approveRole("Candidate", "candidate.txt"); }
void admin::approveAdmins() { approveRole("Admin", "admin.txt"); }

void admin::showrole() { cout << "Role: Admin\n"; }
