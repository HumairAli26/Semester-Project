#include "graph.h"
#include <iostream>
#include <fstream>
using namespace std;

const string Red = "\033[31m";
const string Reset = "\033[0m";
const string Bold = "\033[1m";

void Graph::drawPartyGraph() {
    ifstream file("result.txt");
    if (!file.is_open()) {
        cout << Red << "Error opening result.txt!" << Reset << endl;
        return;
    }

    const int MAX = 100;
    string parties[MAX];
    int wins[MAX] = {0};
    int partyCount = 0;

    string line, currentParty, currentStatus;

    while (getline(file, line)) {
        if (line.find("Party:") == 0) {
            currentParty = line.substr(7);
        }
        if (line.find("Result Status:") == 0) {
            currentStatus = line.substr(15);
            if (currentStatus == "Won") {
                bool found = false;
                for (int i = 0; i < partyCount; i++) {
                    if (parties[i] == currentParty) {
                        wins[i]++;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    parties[partyCount] = currentParty;
                    wins[partyCount] = 1;
                    partyCount++;
                }
            }
        }
    }
    file.close();

    cout << Bold << "\nParty-wise Winning Candidates Graph\n" << Reset;
    for (int i = 0; i < partyCount; i++) {
        cout << parties[i] << " | ";
        for (int j = 0; j < wins[i]; j++)
            cout << "█";  // ASCII block symbol
        cout << " (" << wins[i] << ")" << endl;
    }
}

void Graph::drawCandidateGraph(const string& areaName) {
    ifstream file("result.txt");
    if (!file.is_open()) {
        cout << Red << "Error opening result.txt!" << Reset << endl;
        return;
    }

    const int MAX = 100;
    string names[MAX];
    int votes[MAX] = {0};
    string areas[MAX];
    int count = 0;

    string line, currentName, currentArea, currentVotes;

    while (getline(file, line)) {
        if (line.find("Candidate Name:") == 0) {
            currentName = line.substr(17);
        } else if (line.find("Area:") == 0) {
            currentArea = line.substr(6);
        } else if (line.find("Total Votes:") == 0) {
            currentVotes = line.substr(13);
        } else if (line.find("Result Status:") == 0) {
            if (currentArea == areaName && count < MAX) {
                names[count] = currentName;
                votes[count] = stoi(currentVotes);
                count++;
            }
        }
    }
    file.close();

    if (count == 0) {
        cout << Red << "No candidates found for area: " << areaName << Reset << endl;
        return;
    }

    cout << Bold << "\nCandidate-wise Vote Graph for Area: " << areaName << "\n" << Reset;
    for (int i = 0; i < count; i++) {
        cout << names[i] << " | ";
        for (int j = 0; j < votes[i]; j += 10) // scale votes for display
            cout << "*";
        cout << " (" << votes[i] << " votes)" << endl;
    }
}
