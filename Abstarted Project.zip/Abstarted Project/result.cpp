#include "result.h"
#include <iostream>
#include <fstream>
using namespace std;

const string Red = "\033[31m";
const string Green = "\033[32m";
const string Yellow = "\033[33m";
const string Bold = "\033[1m";
const string Reset = "\033[0m";

Result::Result() {}

Result::Result(const candidate& c, string winStatus) {
    setname(c.getname());
    setage(c.getage());
    setcity(c.getcity());
    setcnic(c.getcnic());
    setrole(c.getrole());
    setpassword(c.getpassword());

    party = c.getparty();
    symbol = c.getsymbol();
    area = c.getarea();
    votecount = c.getvotecount();

    status = winStatus;
}

void Result::setStatus(string s) {
    status = s;
}

string Result::getStatus() const {
    return status;
}

void Result::saveResultToFile() const {
    ofstream file("result.txt", ios::app);
    if (file.is_open()) {
        file << "Candidate Name: " << getname() << endl;
        file << "Party: " << party << endl;
        file << "Symbol: " << symbol << endl;
        file << "Area: " << area << endl;
        file << "Total Votes: " << votecount << endl;
        file << "Result Status: " << status << endl;
        file << "--------------------------" << endl;
        file.close();
        cout << Green << "Result saved for " << getname() << "." << Reset << endl;
    } else {
        cout << Red << "Error writing to result.txt!" << Reset << endl;
    }
}

void Result::resetResults() {
    ofstream file("result.txt", ios::trunc);
    if (file.is_open()) {
        file.close();
        cout << Yellow << "All results have been reset." << Reset << endl;
    } else {
        cout << Red << "Error resetting result.txt!" << Reset << endl;
    }
}

void Result::showAreaResults(const string& areaName) {
    ifstream file("candidates.txt");
    if (!file.is_open()) {
        cout << Red << "Error opening candidates.txt!" << Reset << endl;
        return;
    }

    const int MAX = 100;
    Result results[MAX];
    int count = 0;
    int highestVotes = -1;

    string name, age, cnic, city, role, password, party, symbol, area, votes, eligibility, line;

    while (getline(file, name)) {
        getline(file, age);
        getline(file, cnic);
        getline(file, city);
        getline(file, role);
        getline(file, password);
        getline(file, party);
        getline(file, symbol);
        getline(file, area);
        getline(file, votes);
        getline(file, eligibility);
        getline(file, line);

        if (area == areaName && count < MAX) {
            results[count].setname(name);
            results[count].setage(stoi(age));
            results[count].setcity(city);
            results[count].setcnic(cnic);
            results[count].setrole(role);
            results[count].setpassword(password);
            results[count].setparty(party);
            results[count].setsymbol(symbol);
            results[count].setarea(area);
            results[count].setvotecount(stoi(votes));

            if (stoi(votes) > highestVotes)
                highestVotes = stoi(votes);

            count++;
        }
    }
    file.close();

    if (count == 0) {
        cout << Red << "No candidates found for area: " << areaName << Reset << endl;
        return;
    }

    cout << Bold << "\nResults for area: " << areaName << "\n" << Reset;

    for (int i = 0; i < count; i++) {
        if (results[i].getvotecount() == highestVotes)
            results[i].setStatus("Won");
        else
            results[i].setStatus("Lost");

        results[i].saveResultToFile();

        cout << "----------------------------------" << endl;
        cout << "Candidate: " << results[i].getname() << endl;
        cout << "Party: " << results[i].getparty() << endl;
        cout << "Symbol: " << results[i].getsymbol() << endl;
        cout << "Votes: " << results[i].getvotecount() << endl;
        cout << "Status: " << results[i].getStatus() << endl;
    }
}

void Result::showLeadingParty() {
    ifstream file("result.txt");
    if (!file.is_open()) {
        cout << Red << "Error opening result.txt!" << Reset << endl;
        return;
    }

    const int MAX = 1000;
    string parties[MAX];
    int wins[MAX] = {0};
    int partyCount = 0;

    string line, currentParty, currentStatus;

    while (getline(file, line)) {
        if (line.find("Party:") == 0) {
            currentParty = line.substr(7);
        }
        if (line.find("Result Status:") == 0) {
            currentStatus = line.substr(15);
            if (currentStatus == "Won") {
                bool found = false;
                for (int i = 0; i < partyCount; i++) {
                    if (parties[i] == currentParty) {
                        wins[i]++;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    parties[partyCount] = currentParty;
                    wins[partyCount] = 1;
                    partyCount++;
                }
            }
        }
    }
    file.close();

    if (partyCount == 0) {
        cout << Red << "No winning candidates found in result.txt!" << Reset << endl;
        return;
    }

    int maxIndex = 0;
    for (int i = 1; i < partyCount; i++) {
        if (wins[i] > wins[maxIndex])
            maxIndex = i;
    }

    cout << Bold << "\nParty Wins Summary:\n" << Reset;
    for (int i = 0; i < partyCount; i++) {
        cout << parties[i] << ": " << wins[i] << " winning candidate(s)" << endl;
    }

    cout << Green << "\nLeading Party: " << Bold << parties[maxIndex]
         << Reset << Green << " with " << wins[maxIndex] << " winning candidates!" << Reset << endl;
}
