#include "provincial.h"

const string White = "\033[37m";
const string Red = "\033[31m";
const string Green = "\033[32m";
const string Blue = "\033[34m";
const string Yellow = "\033[33m";
const string Cyan = "\033[36m";
const string Magenta = "\033[35m";
const string Bold = "\033[1m";
const string Reset = "\033[0m";

provincial::provincial(string name, int id) : provincename(name), provinceid(id),
    citycount(0), cityCapacity(5), candidatecount(0), candidateCapacity(5), electionStarted(false) {
    cities = new string[cityCapacity];
    candidates = new candidate*[candidateCapacity];
}

provincial::~provincial() {
    delete[] cities;
    delete[] candidates;
}

void provincial::resizeCities() {
    cityCapacity *= 2;
    string* newCities = new string[cityCapacity];
    for (int i = 0; i < citycount; i++)
        newCities[i] = cities[i];
    delete[] cities;
    cities = newCities;
}

void provincial::resizeCandidates() {
    candidateCapacity *= 2;
    candidate** newCandidates = new candidate*[candidateCapacity];
    for (int i = 0; i < candidatecount; i++)
        newCandidates[i] = candidates[i];
    delete[] candidates;
    candidates = newCandidates;
}

void provincial::addCity(const string& city) {
    if (citycount == cityCapacity)
        resizeCities();
    cities[citycount++] = city;
}

void provincial::loadCandidatesFromFile() {
    ifstream file("candidates.txt");
    string name, age, cnic, city, role, password, party, symbol, area, votes, eligibility, sep;

    while (getline(file, name)) {
        getline(file, age);
        getline(file, cnic);
        getline(file, city);
        getline(file, role);
        getline(file, password);
        getline(file, party);
        getline(file, symbol);
        getline(file, area);
        getline(file, votes);
        getline(file, eligibility);
        getline(file, sep);

        for (int i = 0; i < citycount; i++) {
            if (cities[i] == area) {
                if (candidatecount == candidateCapacity)
                    resizeCandidates();

                candidate* c = new candidate();
                c->setname(name);
                c->setage(stoi(age));
                c->setcnic(cnic);
                c->setcity(city);
                c->setrole(role);
                c->setpassword(password);
                c->setparty(party);
                c->setsymbol(symbol);
                c->setarea(area);
                c->setvotecount(stoi(votes));

                candidates[candidatecount++] = c;
                break;
            }
        }
    }
    file.close();
}

void provincial::createElection() {
    electionStarted = true;
    cout << Green << "Provincial Election started in " << provincename << Reset << endl;
}

void provincial::showCandidates() {
    if (!electionStarted) {
        cout << Yellow << "Election not started in " << provincename << Reset << endl;
        return;
    }
    for (int i = 0; i < candidatecount; i++)
        candidates[i]->displaydetails();
}

string provincial::getWinningParty() {
    string* parties = new string[candidatecount];
    int* seats = new int[candidatecount];
    int partycount = 0;

    for (int i = 0; i < candidatecount; i++) {
        string pname = candidates[i]->getparty();
        bool found = false;
        for (int j = 0; j < partycount; j++) {
            if (parties[j] == pname) {
                seats[j]++;
                found = true;
                break;
            }
        }
        if (!found) {
            parties[partycount] = pname;
            seats[partycount++] = 1;
        }
    }

    int maxSeats = 0;
    string winner = "None";
    for (int i = 0; i < partycount; i++) {
        if (seats[i] > maxSeats) {
            maxSeats = seats[i];
            winner = parties[i];
        }
    }

    delete[] parties;
    delete[] seats;
    return winner;
}

int provincial::getCandidateCount() const {
    return candidatecount;
}

candidate* provincial::getCandidateAt(int index) {
    return (index >= 0 && index < candidatecount) ? candidates[index] : nullptr;
}

string provincial::getProvinceName() const {
    return provincename;
}

bool provincial::hasStarted() const {
    return electionStarted;
}
