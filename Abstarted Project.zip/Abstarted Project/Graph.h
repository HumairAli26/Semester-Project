#pragma once
#include <string>
using namespace std;

class Graph 
{
public:
    static void drawPartyGraph();
    static void drawCandidateGraph(const string& areaName);
};
