#include "user.h"

const string White = "\033[37m";
const string Red = "\033[31m";
const string Green = "\033[32m";
const string Blue = "\033[34m";
const string Yellow = "\033[33m";
const string Cyan = "\033[36m";
const string Magenta = "\033[35m";
const string Bold = "\033[1m";
const string Reset = "\033[0m";

bool isCNICDuplicate(const string &cnic)
{
    string line;
    ifstream files[] = {
        ifstream("voter.txt"),
        ifstream("candidate.txt"),
        ifstream("admin.txt"),
        ifstream("Approval.txt")};

    for (auto &file : files)
    {
        while (getline(file, line))
        {
            if (line == cnic)
            {
                file.close();
                return true;
            }
        }
        file.close();
    }
    return false;
}

bool isValidCNIC(const string &input)
{
    if (input.length() != 15)
    {
        cout << Red << "Invalid Length! CNIC must be 15 characters (xxxxx-xxxxxxx-x).\n" << Reset;
        return false;
    }

    for (char ch : input)
    {
        if (!isdigit(ch) && ch != '-')
        {
            cout << Red << "Invalid input! Only digits and '-' are allowed.\n" << Reset;
            return false;
        }
    }
    return true;
}

bool isOnlyAlphabet(const string &input)
{
    if (input.empty())
    {
        cout << Red << "Input cannot be empty.\n" << Reset;
        return false;
    }

    for (char ch : input)
    {
        if (isdigit(ch))
        {
            cout << Red << "Invalid input! Digits are not allowed.\n" << Reset;
            return false;
        }
    }
    return true;
}

// Constructors
user::user() : name(""), age(0), city(""), cnic(""), role(""), password("") {}

user::user(string n, int a, string c, string cn, string r, string p)
    : name(n), age(a), city(c), cnic(cn), role(r), password(p) {}

// Setters
void user::setname(string n) {
    if (isOnlyAlphabet(n)) name = n;
}

void user::setage(int a) {
    age = a;
}

void user::setcity(string c) {
    if (isOnlyAlphabet(c)) city = c;
}

void user::setcnic(string cn) {
    if (isValidCNIC(cn)) cnic = cn;
}

void user::setrole(string r) {
    if (isOnlyAlphabet(r)) role = r;
}

void user::setpassword(string p) {
    password = p;
}

// Getters
string user::getname() const { return name; }
int user::getage() const { return age; }
string user::getcity() const { return city; }
string user::getcnic() const { return cnic; }
string user::getrole() const { return role; }
string user::getpassword() const { return password; }

// Display user info
void user::displayuserinfo() const {
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "CNIC: " << cnic << endl;
    cout << "City: " << city << endl;
    cout << "Role: " << role << endl;
}

// File operations
void user::saveToFile() const {
    ofstream file("user.txt", ios::app);
    if (file.is_open()) {
        file << name << endl << age << endl << cnic << endl
             << city << endl << role << endl << "----------" << endl;
        file.close();
        cout << "User data saved to file successfully." << endl;
    } else {
        cout << "Error! Could Not open the file for writing" << endl;
    }
}

void user::readAllUsers() {
    ifstream file("user.txt");
    string line;
    if (file.is_open()) {
        cout << "\nAll Users from File:" << endl;
        while (getline(file, line)) {
            cout << line << endl;
        }
        file.close();
    } else {
        cout << "Error opening user file.\n";
    }
}
