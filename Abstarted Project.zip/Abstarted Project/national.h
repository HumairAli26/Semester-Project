#pragma once
#include <iostream>
#include <string>
#include "provincial.h"
using namespace std;

const string White = "\033[37m";
const string Red = "\033[31m";
const string Green = "\033[32m";
const string Blue = "\033[34m";
const string Yellow = "\033[33m";
const string Cyan = "\033[36m";
const string Magenta = "\033[35m";
const string Bold = "\033[1m";
const string Reset = "\033[0m";

class national_election {
private:
    provincial** provinces;
    int provinceCount;
    int provinceCapacity;

    void resizeProvinces();

public:
    national_election();
    ~national_election();

    void addProvince(provincial* p);
    void createElection();
    void showAllCandidates();
    string getNationalWinner();
};
