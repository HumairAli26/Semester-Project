#ifndef CANDIDATE_H
#define CANDIDATE_H

#include "user.h"

class candidate : virtual public user
{
protected:
    string electsymbol;
    string CandidateID;
    string party;
    string symbol;
    string area;
    int votecount;
    bool eligibility;

public:
    candidate();
    candidate(string n, int a, string c, string cn, string r, string p, string es, string cID);

    string getCandidateID();
    string getelectsymbol();
    bool iseligble();
    void showrole() override;

    void setDetails();
    void update();
    void removeCandidate();
    void saveToFile();
    void displaydetails();
    void candidateMenu(candidate &c);

    void setparty(string p);
    void setsymbol(string s);
    void setarea(string a);
    void setvotecount(int v);

    string getparty() const;
    string getsymbol() const;
    string getarea() const;
    int getvotecount() const;

    void incrementvote();
    void resetvotecount();
};

#endif