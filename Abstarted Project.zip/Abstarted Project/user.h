#pragma once
#include <iostream>
#include <fstream>
using namespace std;

class user 
{
private:
    string name;
    int age;
    string city;
    string cnic;
    string role;
    string password;

public:
    user();
    user(string n, int a, string c, string cn, string r, string p);

    // Setters
    void setname(string n);
    void setage(int a);
    void setcity(string c);
    void setcnic(string cn);
    void setrole(string r);
    void setpassword(string p);

    // Getters
    string getname() const;
    int getage() const;
    string getcity() const;
    string getcnic() const;
    string getrole() const;
    string getpassword() const;

    // Functionalities
    void displayuserinfo() const;
    virtual void showrole() = 0;
    void saveToFile() const;
    static void readAllUsers();
};
