#include"user.h"
#include"candidate.h"
#include"Voter.h"
#include"admin.h"
#include"Graph.h"
#include"result.h"
#include"national.h"
#include"provincial.h"
#include <iostream>
#include <fstream>
#include <string>

bool isCNICDuplicate(const string &cnic)
{
    string line;
    ifstream files[] = {
        ifstream("voter.txt"),
        ifstream("candidate.txt"),
        ifstream("admin.txt"),
        ifstream("Approval.txt")};

    for (auto &file : files)
    {
        while (getline(file, line))
        {
            if (line == cnic)
            {
                file.close();
                return true;
            }
        }
        file.close();
    }
    return false;
}

void interface_logo()
{
    cout << White << "=====================================================================" << endl;
    cout << White << "#                   E - V O T I N G   S Y S T E M                   #" << endl;
    cout << White << "=====================================================================" << endl;
}

void login_page()
{
    int n;
    string entered_id, entered_pw;

    while (true)
    {
        cout << "\n\t\t\tSelect your Role:" << endl;
        cout << "\t\t\t\t" << Blue << "1." << Reset << " Voter" << endl;
        cout << "\t\t\t\t" << Blue << "2." << Reset << " Candidate" << endl;
        cout << "\t\t\t\t" << Blue << "3." << Reset << " Admin" << endl;
        cout << "\t\t\t\t" << Blue << "0." << Reset << " Exit" << endl;
        cin >> n;

        if (n == 0)
        {
            cout << Yellow << "Exiting the system. Goodbye!\n" << Reset;
            break;
        }

        cin.ignore();
        cout << "Enter Your ID (VoterID / CandidateID / AdminID): ";
        getline(cin, entered_id);

        string filename;
        if (n == 1)
            filename = "voter.txt";
        else if (n == 2)
            filename = "candidates.txt";
        else if (n == 3)
            filename = "admin.txt";
        else
        {
            cout << Red << "Invalid role choice.\n" << Reset;
            continue;
        }

        ifstream file(filename);
        if (!file.is_open())
        {
            cout << Red << "Error opening " << filename << Reset << endl;
            continue;
        }

        string line, name, age, cnic, city, role, password;
        bool found = false, correctPassword = false;

        while (getline(file, name))
        {
            string userBlock = name + "\n";
            getline(file, age); userBlock += age + "\n";
            getline(file, cnic); userBlock += cnic + "\n";
            getline(file, city); userBlock += city + "\n";
            getline(file, role); userBlock += role + "\n";
            getline(file, password); userBlock += password + "\n";

            string userID;

            if (role == "Voter")
            {
                string area, hasvoted, sep;
                getline(file, userID); userBlock += userID + "\n";
                getline(file, area); userBlock += area + "\n";
                getline(file, hasvoted); userBlock += hasvoted + "\n";
                getline(file, sep); userBlock += sep + "\n";

                if (entered_id == userID)
                {
                    for (int attempts = 1; attempts <= 3; attempts++)
                    {
                        cout << "Enter Password: ";
                        getline(cin, entered_pw);
                        if (entered_pw == password)
                        {
                            correctPassword = true;
                            break;
                        }
                        else
                        {
                            cout << Red << "Wrong password! Attempt " << attempts << "/3\n" << Reset;
                        }
                    }

                    if (!correctPassword)
                    {
                        cout << Red << "Too many wrong attempts. User blocked.\n\n" << Reset;

                        ofstream blockFile("block.txt", ios::app);
                        blockFile << userBlock;
                        blockFile << "----------------\n";
                        blockFile.close();

                        ifstream inFile(filename);
                        ofstream tempFile("temp.txt");
                        string tempLine, currentBlock = "";
                        bool skip = false;

                        while (getline(inFile, tempLine))
                        {
                            currentBlock += tempLine + "\n";
                            if (tempLine == userID)
                                skip = true;

                            if (tempLine == "----------------")
                            {
                                if (!skip)
                                    tempFile << currentBlock;
                                currentBlock = "";
                                skip = false;
                            }
                        }
                        inFile.close();
                        tempFile.close();
                        remove(filename.c_str());
                        rename("temp.txt", filename.c_str());
                        break;
                    }
                    found = true;
                    cout << Green << "Welcome " << name << "! (Voter)\n" << Reset;
                    voter v(name, stoi(age), city, cnic, role, password, userID, area);
                    v.sethasvoted(hasvoted == "1");
                    v.displayMenu(v);
                    break;
                }
            }
            else if (role == "Candidate")
            {
                string candidateID, party, symbol, area, votes, eligible, sep;
                getline(file, candidateID);
                getline(file, party);
                getline(file, symbol);
                getline(file, area);
                getline(file, votes);
                getline(file, eligible);
                getline(file, sep);

                userBlock += candidateID + "\n" + party + "\n" + symbol + "\n" + area + "\n" +
                             votes + "\n" + eligible + "\n" + sep + "\n";

                if (entered_id == candidateID)
                {
                    for (int attempts = 1; attempts <= 3; attempts++)
                    {
                        cout << "Enter Password: ";
                        getline(cin, entered_pw);

                        if (entered_pw == password)
                        {
                            correctPassword = true;
                            break;
                        }
                        else
                        {
                            cout << Red << "Wrong password! Attempt " << attempts << "/3\n" << Reset;
                        }
                    }

                    if (!correctPassword)
                    {
                        cout << Red << "Too many wrong attempts. Candidate blocked.\n\n" << Reset;

                        ofstream blockFile("block.txt", ios::app);
                        blockFile << userBlock;
                        blockFile << "----------------\n";
                        blockFile.close();

                        ifstream inFile(filename);
                        ofstream tempFile("temp.txt");
                        string tempLine, currentBlock = "";
                        bool skip = false;

                        while (getline(inFile, tempLine))
                        {
                            currentBlock += tempLine + "\n";
                            if (tempLine == candidateID)
                                skip = true;

                            if (tempLine == "----------------")
                            {
                                if (!skip)
                                    tempFile << currentBlock;
                                currentBlock = "";
                                skip = false;
                            }
                        }

                        inFile.close();
                        tempFile.close();
                        remove(filename.c_str());
                        rename("temp.txt", filename.c_str());
                        break;
                    }

                    found = true;
                    cout << Green << "Welcome " << name << "! (Candidate)\n" << Reset;
                    candidate c(name, stoi(age), city, cnic, role, password, symbol, candidateID);
                    c.setparty(party);
                    c.setarea(area);
                    c.setvotecount(stoi(votes));
                    c.candidateMenu(c);
                    break;
                }
            }
            else if (role == "Admin")
            {
                string sep;
                getline(file, userID); userBlock += userID + "\n";
                getline(file, sep); userBlock += sep + "\n";

                if (entered_id == userID)
                {
                    for (int attempts = 1; attempts <= 3; attempts++)
                    {
                        cout << "Enter Password: ";
                        getline(cin, entered_pw);
                        if (entered_pw == password)
                        {
                            correctPassword = true;
                            break;
                        }
                        else
                        {
                            cout << Red << "Wrong password! Attempt " << attempts << "/3\n" << Reset;
                        }
                    }

                    if (!correctPassword)
                    {
                        cout << Red << "Too many wrong attempts. Admin blocked.\n\n" << Reset;

                        ofstream blockFile("block.txt", ios::app);
                        blockFile << userBlock;
                        blockFile << "----------------\n";
                        blockFile.close();

                        ifstream inFile(filename);
                        ofstream tempFile("temp.txt");
                        string tempLine, currentBlock = "";
                        bool skip = false;

                        while (getline(inFile, tempLine))
                        {
                            currentBlock += tempLine + "\n";
                            if (tempLine == userID)
                                skip = true;

                            if (tempLine == "----------------")
                            {
                                if (!skip)
                                    tempFile << currentBlock;
                                currentBlock = "";
                                skip = false;
                            }
                        }
                        inFile.close();
                        tempFile.close();
                        remove(filename.c_str());
                        rename("temp.txt", filename.c_str());
                        break;
                    }
                    found = true;
                    cout << Green << "Welcome Admin " << name << "!\n" << Reset;
                    admin a(name, stoi(age), city, cnic, role, password);
                    a.adminMenu();
                    break;
                }
            }
        }

        file.close();
        if (!found && !correctPassword)
        {
            cout << Red << "Incorrect ID or user not found.\n\n" << Reset;
        }
    }
}

void signup()
{
    string name, city, cnic, password, id, area, party, symbol, role;
    int age;

    cin.ignore();
    cout << "Enter Role (Voter/Candidate/Admin): ";
    getline(cin, role);

    cout << "Enter Name: ";
    getline(cin, name);

    cout << "Enter Age: ";
    while (!(cin >> age) || age < 18 || age > 120)
    {
        cout << Red << "Invalid age. Enter a number between 18 and 120: " << Reset;
        cin.clear();
        cin.ignore(10000, '\n');
    }
    cin.ignore();

    cout << "Enter City: ";
    getline(cin, city);

    cout << "Enter CNIC: ";
    getline(cin, cnic);
    if (isCNICDuplicate(cnic))
    {
        cout << "Error: CNIC already exists!\n";
        return;
    }

    cout << "Enter Password: ";
    getline(cin, password);

    if (role == "Voter")
    {
        cout << "Enter Voter ID: ";
        getline(cin, id);
        cout << "Enter Area: ";
        getline(cin, area);
    }
    else if (role == "Candidate")
    {
        cout << "Enter Candidate ID: ";
        getline(cin, id);
        cout << "Enter Party: ";
        getline(cin, party);
        cout << "Enter Symbol: ";
        getline(cin, symbol);
        cout << "Enter Area: ";
        getline(cin, area);
    }
    else if (role == "Admin")
    {
        cout << "Enter Admin ID: ";
        getline(cin, id);
    }
    else
    {
        cout << "Invalid role.\n";
        return;
    }

    ofstream file("Approval.txt", ios::app);
    if (!file)
    {
        cout << "Error opening approval file.\n";
        return;
    }

    file << name << endl;
    file << age << endl;
    file << cnic << endl;
    file << city << endl;
    file << role << endl;
    file << password << endl;
    file << id << endl;
    if (role == "Voter")
    {
        file << area << endl;
        file << "0\n";
    }
    else if (role == "Candidate")
    {
        file << party << endl;
        file << symbol << endl;
        file << area << endl;
        file << "0\n1\n";
    }
    file << "----------\n";
    file.close();
    cout << role << " account submitted for approval.\n";
}

int main()
{

    interface_logo();

    int choice;
    cout << "Enter Your Choice" << endl;
    cout << "\t\t\t\t" << Blue << "1." <<Reset<<"  Login" << endl;
    cout <<  "\t\t\t\t" << Blue << "2." <<Reset<<"  Sign Up" << endl;
    cin >> choice;
    switch (choice)
    {
    case 1:
        login_page();
        break;
    case 2:
        signup();
        break;
    default:
        break;
    }
    return 0;
}