#include "candidate.h"
#include <iostream>
#include <fstream>
#include <limits>
#include <algorithm>
using namespace std;

candidate::candidate() : user(), party(""), symbol(""), area(""), votecount(0), eligibility(true) {}

candidate::candidate(string n, int a, string c, string cn, string r, string p, string es, string cID)
    : user(n, a, c, cn, r, p), CandidateID(cID), electsymbol(es) {}

string candidate::getCandidateID() { return CandidateID; }
string candidate::getelectsymbol() { return electsymbol; }

bool candidate::iseligble() { return eligibility && getage() >= 18; }

void candidate::showrole() { cout << "Role: Candidate (" << party << ")\n"; }

void candidate::setDetails()
{
    string n, p, s, c, a, r, cn, pw;
    int age;

    cout << "Enter candidate details:\n";
    cout << "Name: ";
    cin.ignore(); getline(cin, n); setname(n);

    cout << "Age: "; cin >> age; setage(age);
    cin.ignore();

    cout << "Party: "; getline(cin, party);
    cout << "Symbol: "; getline(cin, symbol);
    cout << "Role: "; getline(cin, r); setrole(r);
    cout << "Candidate ID: "; getline(cin, CandidateID);
    cout << "City: "; getline(cin, c); setcity(c);
    cout << "Area: "; getline(cin, area);
    cout << "CNIC: "; getline(cin, cn); setcnic(cn);
    cout << "Password: "; getline(cin, pw); setpassword(pw);
}

void candidate::update()
{
    string targetID;
    cout << "Enter the Candidate ID to update: ";
    cin.ignore(); getline(cin, targetID);

    ifstream fin("candidates.txt");
    ofstream fout("temp.txt");

    if (!fin || !fout) { cout << "Error opening file.\n"; return; }

    string name, age, cnic, city, role, password, candidateID, party, symbol, area, votes, eligibility, sep;
    bool found = false;

    while (getline(fin, name))
    {
        getline(fin, age); getline(fin, cnic); getline(fin, city);
        getline(fin, role); getline(fin, password); getline(fin, candidateID);
        getline(fin, party); getline(fin, symbol); getline(fin, area);
        getline(fin, votes); getline(fin, eligibility); getline(fin, sep);

        if (candidateID == targetID)
        {
            found = true;
            int choice;
            cout << "\nMatch Found!\n1. Area\n2. Password\n3. City\n4. CNIC\nChoice: ";
            cin >> choice; cin.ignore();
            switch (choice)
            {
            case 1: cout << "New Area: "; getline(cin, area); break;
            case 2: cout << "New Password: "; getline(cin, password); break;
            case 3: cout << "New City: "; getline(cin, city); break;
            case 4: cout << "New CNIC: "; getline(cin, cnic); break;
            default: cout << "Invalid choice.\n";
            }
            cout << "Information updated successfully.\n";
        }

        fout << name << "\n" << age << "\n" << cnic << "\n" << city << "\n"
             << role << "\n" << password << "\n" << candidateID << "\n"
             << party << "\n" << symbol << "\n" << area << "\n"
             << votes << "\n" << eligibility << "\n----------\n";
    }

    fin.close(); fout.close();
    remove("candidates.txt"); rename("temp.txt", "candidates.txt");
    if (!found) cout << "No Candidate found with ID: " << targetID << "\n";
}

void candidate::removeCandidate()
{
    string targetID;
    cout << "Enter the Candidate ID to remove: ";
    cin.ignore(); getline(cin, targetID);

    ifstream fin("candidates.txt");
    ofstream fout("temp.txt");

    if (!fin || !fout) { cout << "Error opening file.\n"; return; }

    string name, age, cnic, city, role, password, candidateID, party, symbol, area, votes, eligibility, sep;
    bool found = false;

    while (getline(fin, name))
    {
        getline(fin, age); getline(fin, cnic); getline(fin, city);
        getline(fin, role); getline(fin, password); getline(fin, candidateID);
        getline(fin, party); getline(fin, symbol); getline(fin, area);
        getline(fin, votes); getline(fin, eligibility); getline(fin, sep);

        if (candidateID != targetID)
        {
            fout << name << "\n" << age << "\n" << cnic << "\n" << city << "\n"
                 << role << "\n" << password << "\n" << candidateID << "\n"
                 << party << "\n" << symbol << "\n" << area << "\n"
                 << votes << "\n" << eligibility << "\n----------\n";
        }
        else
        {
            found = true;
            cout << "Candidate with ID " << targetID << " removed.\n";
        }
    }

    fin.close(); fout.close();
    remove("candidates.txt"); rename("temp.txt", "candidates.txt");
    if (!found) cout << "No candidate found with ID: " << targetID << "\n";
}

void candidate::saveToFile()
{
    ofstream fout("candidates.txt", ios::app);
    if (fout)
    {
        fout << getname() << "\n" << getage() << "\n" << getcnic() << "\n"
             << getcity() << "\n" << getrole() << "\n" << getpassword() << "\n"
             << CandidateID << "\n" << party << "\n" << symbol << "\n"
             << area << "\n" << votecount << "\n" << eligibility << "\n----------\n";
    }
    else cout << "Error writing to file.\n";
}

void candidate::displaydetails()
{
    ifstream fin("candidates.txt");
    string name, age, cnic, city, role, password, candidateID, party, symbol, area, votes, eligible, sep;

    while (getline(fin, name))
    {
        getline(fin, age); getline(fin, cnic); getline(fin, city);
        getline(fin, role); getline(fin, password); getline(fin, candidateID);
        getline(fin, party); getline(fin, symbol); getline(fin, area);
        getline(fin, votes); getline(fin, eligible); getline(fin, sep);

        if (cnic == this->getcnic())
        {
            cout << "\nCandidate Details:\n";
            cout << "Name: " << name << "\nAge: " << age << "\nCNIC: " << cnic
                 << "\nCity: " << city << "\nRole: " << role << "\nCandidate ID: " << candidateID
                 << "\nParty: " << party << "\nSymbol: " << symbol << "\nArea: " << area
                 << "\nVotes: " << votes << "\nEligible: " << (eligible == "1" ? "Yes" : "No") << endl;
            return;
        }
    }
    cout << "Candidate not found.\n";
}

void candidate::candidateMenu(candidate &c)
{
    int choice;
    do
    {
        cout << "\nCandidate Menu:\n";
        cout << "1. View Info\n2. View Vote Count\n3. Area Standing\n0. Log Out\nChoice: ";
        cin >> choice; cin.ignore();

        switch (choice)
        {
        case 1: c.displaydetails(); break;
        case 2:
        {
            ifstream fin("candidates.txt");
            string name, age, cnic, city, role, password, candidateID, party, symbol, area, votesStr, eligible, sep;
            while (getline(fin, name))
            {
                getline(fin, age); getline(fin, cnic); getline(fin, city);
                getline(fin, role); getline(fin, password); getline(fin, candidateID);
                getline(fin, party); getline(fin, symbol); getline(fin, area);
                getline(fin, votesStr); getline(fin, eligible); getline(fin, sep);

                if (candidateID == this->CandidateID)
                {
                    cout << "Vote Count: " << votesStr << endl;
                    break;
                }
            }
            fin.close();
            break;
        }
        case 3:
        {
            string targetArea;
            cout << "Enter Area: ";
            getline(cin, targetArea);

            ifstream fin("candidates.txt");
            const int MAX = 100;
            string names[MAX], parties[MAX], symbols[MAX];
            int votes[MAX], count = 0;

            string name, age, cnic, city, role, password, candidateID, party, symbol, area, votesStr, eligible, sep;

            while (getline(fin, name))
            {
                getline(fin, age); getline(fin, cnic); getline(fin, city);
                getline(fin, role); getline(fin, password); getline(fin, candidateID);
                getline(fin, party); getline(fin, symbol); getline(fin, area);
                getline(fin, votesStr); getline(fin, eligible); getline(fin, sep);

                if (area == targetArea && count < MAX)
                {
                    names[count] = name;
                    parties[count] = party;
                    symbols[count] = symbol;
                    votes[count] = stoi(votesStr);
                    count++;
                }
            }
            fin.close();

            sort(votes, votes + count); // Optional: Use stable_sort to retain names
            cout << "\nCandidates in " << targetArea << ":\n";
            for (int i = 0; i < count; i++)
            {
                cout << names[i] << " (" << parties[i] << ") - " << symbols[i]
                     << " - Votes: " << votes[i] << endl;
            }
            break;
        }
        case 0:
            cout << "Logging out...\n"; break;
        default:
            cout << "Invalid choice.\n";
        }

    } while (choice != 0);
}

void candidate::setparty(string p) { party = p; }
void candidate::setsymbol(string s) { symbol = s; }
void candidate::setarea(string a) { area = a; }
void candidate::setvotecount(int v) { votecount = v; }
string candidate::getparty() const { return party; }
string candidate::getsymbol() const { return symbol; }
string candidate::getarea() const { return area; }
int candidate::getvotecount() const { return votecount; }
void candidate::incrementvote() { votecount++; }
void candidate::resetvotecount() { votecount = 0; }
