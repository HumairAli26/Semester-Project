#ifndef EVOTINGSYSTEM_H
#define EVOTINGSYSTEM_H

#include <iostream>
#include <fstream>
#include <string>
#include <ctime>

// Color codes
const std::string White = "\033[37m";
const std::string Red = "\033[31m";
const std::string Green = "\033[32m";
const std::string Blue = "\033[34m";
const std::string Yellow = "\033[33m";
const std::string Cyan = "\033[36m";
const std::string Bold = "\033[1m";
const std::string Reset = "\033[0m";

// Helper functions
tm parseCTimeString(const std::string &timeStr);
bool isElectionActive(const std::string &fileName);
bool isCNICDuplicate(const std::string &cnic);
bool isValidCNIC(const std::string &input);
bool isOnlyAlphabet(const std::string &input);
void interface_logo();

// Base User class
class User {
protected:
    std::string name;
    int age;
    std::string city;
    std::string cnic;
    std::string role;
    std::string password;
    
public:
    User();
    User(std::string n, int a, std::string c, std::string cn, std::string r, std::string p);
    
    // Setters
    void setname(std::string n);
    void setage(int a);
    void setcity(std::string c);
    void setcnic(std::string cn);
    void setrole(std::string r);
    void setpassword(std::string p);
    
    // Getters
    std::string getname() const;
    int getage() const;
    std::string getcity() const;
    std::string getcnic() const;
    std::string getrole() const;
    std::string getpassword() const;
    
    void displayuserinfo();
    virtual void showrole() = 0;
    void saveToFile();
    void readAllUsers();
};

// Candidate class
class Candidate : virtual public User {
protected:
    std::string electsymbol;
    std::string CandidateID;
    std::string party;
    std::string symbol;
    std::string area;
    int votecount;
    bool eligibility;
    
public:
    Candidate();
    Candidate(std::string n, int a, std::string c, std::string cn, std::string r, 
             std::string p, std::string es, std::string cID);
    
    std::string getCandidateID();
    std::string getelectsymbol();
    bool iseligble();
    void showrole() override;
    void setDetails();
    void update();
    void displaydetails();
    void removeCandidate();
    void saveToFile();
    void candidateMenu(Candidate &c);
    
    // Setters
    void setparty(std::string p);
    void setsymbol(std::string s);
    void setarea(std::string a);
    void setvotecount(int v);
    
    // Getters
    std::string getparty() const;
    std::string getsymbol() const;
    std::string getarea() const;
    int getvotecount() const;
    
    void incrementvote();
    void resetvotecount();
};

// Voter class
class Voter : virtual public User {
private:
    std::string voterID;
    bool hasvoted;
    std::string area;
    
public:
    Voter();
    Voter(std::string n, int a, std::string c, std::string cn, std::string r, 
         std::string p, std::string vid, std::string assigned_area);
    
    // Setters/Getters
    void sethasvoted(bool voted);
    bool gethasvoted() const;
    std::string getVoterID() const;
    std::string getArea() const;
    
    void setDetails();
    void update();
    void cast_vote(const std::string &voterID_loggedIn);
    void displayDetails();
    void saveToFile();
    void deleteVoter();
    void deleteAllVoters();
    bool matchArea(const std::string &voterArea);
    void showrole() override;
    void displayMenu(Voter &v);
};

// Graph class
class Graph {
public:
    static void drawPartyGraph();
    static void drawCandidateGraph(const std::string &areaName);
};

// Result class
class Result : virtual public Candidate, virtual public Graph {
private:
    std::string status;
    
public:
    Result();
    Result(const Candidate &c, std::string winStatus);
    
    void setStatus(std::string s);
    std::string getStatus() const;
    void saveResultToFile() const;
    static void resetResults();
    static void showAreaResults(const std::string &areaName);
    void showLeadingParty();
};

// Admin class
class Admin : public Voter, public Result {
    int electionCount;
    
public:
    Admin(std::string name = "", int age = 0, std::string city = "", 
         std::string cnic = "", std::string role = "Admin", std::string password = "");
    
    void adminMenu();
    void updateUsers();
    void removeUsers();
    void addUsers();
    void approvedPendingUsers();
    void createElection();
    void addCandidate();
    void updateCandidate();
    void removeCandidate();
    void addNewVoter();
    void updateVoter();
    void removeVoter();
    void deleteAllVotersData();
    void resetResults();
    void showResults();
    void showrole() override;
    
private:
    void approveRole(const std::string &targetRole, const std::string &outputFile);
    void approveVoters();
    void approveCandidates();
    void approveAdmins();
};

// Provincial class
class Provincial {
private:
    std::string provincename;
    int provinceid;
    std::string *cities;
    int citycount;
    int cityCapacity;
    Candidate **candidates;
    int candidatecount;
    int candidateCapacity;
    bool electionStarted;
    
public:
    Provincial(std::string name = "", int id = 0);
    ~Provincial();
    
    void resizeCities();
    void resizeCandidates();
    void addCity(const std::string &city);
    void loadCandidatesFromFile();
    void createElection();
    void showCandidates();
    std::string getWinningParty();
    int getCandidateCount() const;
    Candidate *getCandidateAt(int index);
    std::string getProvinceName() const;
    bool hasStarted() const;
};

// NationalElection class
class NationalElection {
private:
    Provincial **provinces;
    int provinceCount;
    int provinceCapacity;
    
public:
    NationalElection();
    ~NationalElection();
    
    void resizeProvinces();
    void addProvince(Provincial *p);
    void createElection();
    void showAllCandidates();
    std::string getNationalWinner();
};

// Main functions
void login_page();
void signup();

#endif // EVOTINGSYSTEM_H