#include"E_Voting.h"

using namespace std;

int main()
{

    interface_logo();

    int choice;
    cout << "Enter Your Choice" << endl;
    cout << "\t\t\t\t" << Blue << "1." <<Reset<<"  Login" << endl;
    cout <<  "\t\t\t\t" << Blue << "2." <<Reset<<"  Sign Up" << endl;
    cin >> choice;
    switch (choice)
    {
    case 1:
        login_page();
        break;
    case 2:
        signup();
        break;
    default:
        break;
    }
    return 0;
}